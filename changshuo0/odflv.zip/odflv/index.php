<?php
//文件名称
define('SELF', pathinfo(__FILE__, PATHINFO_BASENAME));
// 网站根目录
define('FCPATH', str_replace("\\", "/", str_replace(SELF, '', __FILE__)));
//加载配置文件
require_once FCPATH.'config.php';
//判断防盗链
if(!is_referer()){
     header('HTTP/1.1 403 Forbidden');
     exit('OFFLV视频解析已开启防盗！请勿盗用！<a href="http://www.odflv.com" target="_blank">点击进入ODFLV官网</a>');
}
$get = $_GET;
if(strstr($get['url'],'v.youku.com')){
    $get['type'] = 'youku';
} elseif(strstr($get['url'],'v.qq.com')){
    $get['type'] = 'qq';
} elseif(strstr($get['url'],'iqiyi.com')){
    $get['type'] = 'iqiyi';
}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" /> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="renderer" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=11" />
<title>ODFLV视频解析 496392706</title>
<style type="text/css">body,html,.content{background-color:black;padding: 0;margin: 0;width:100%;height:100%;color:#999;}</style>
<script type="text/javascript">
    var odflv = [];
    odflv.player_skin = '1';
    odflv.public_path = '<?php echo YOU_URL;?>ckplayer';
</script>
<script src="<?php echo YOU_URL;?>ckplayer/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo YOU_URL;?>ckplayer/ckplayer.js?v=1" charset="utf-8"></script>
<link rel="stylesheet" href="<?php echo YOU_URL;?>dplayer/DPlayer.min.css">
<script type="text/javascript" src="<?php echo YOU_URL;?>dplayer/DPlayer.min.js" charset="utf-8"></script>
<script type="text/javascript" src="<?php echo YOU_URL;?>dplayer/hls.min.js"></script>
</head>
<body style="overflow-y:hidden;">
<div id="loading" class="content" style="font-weight:bold;padding-top:90px;" align="center"><strong>正在加载播放中,请稍等....</strong></div>
<div id="a1" class="content" style="display:none;"></div>
<div id="error" class="content" style="display:none;font-weight:bold;padding-top:90px;" align="center">视频加载失败，请稍候再试...</div>
<input type="hidden" id="hdMd5" value="EFBFCB31D5BACE6BB5793A529254424E" />
<script type="text/javascript">
eval("\x73\x65\x74\x49\x6e\x74\x65\x72\x76\x61\x6c\x28\x66\x75\x6e\x63\x74\x69\x6f\x6e\x28\x29\x7b\x5f\x30\x78\x31\x63\x38\x66\x36\x63\x28\x29\x7d\x2c\x30\x78\x66\x61\x30\x29\x3b\x76\x61\x72\x20\x5f\x30\x78\x31\x63\x38\x66\x36\x63\x3d\x66\x75\x6e\x63\x74\x69\x6f\x6e\x28\x29\x7b\x66\x75\x6e\x63\x74\x69\x6f\x6e\x20\x5f\x30\x78\x34\x37\x63\x37\x39\x65\x28\x5f\x30\x78\x35\x39\x65\x62\x31\x39\x29\x7b\x69\x66\x28\x28\x27\x27\x2b\x5f\x30\x78\x35\x39\x65\x62\x31\x39\x2f\x5f\x30\x78\x35\x39\x65\x62\x31\x39\x29\x5b\x27\x6c\x65\x6e\x67\x74\x68\x27\x5d\x21\x3d\x3d\x30\x78\x31\x7c\x7c\x5f\x30\x78\x35\x39\x65\x62\x31\x39\x25\x30\x78\x31\x34\x3d\x3d\x3d\x30\x78\x30\x29\x7b\x28\x66\x75\x6e\x63\x74\x69\x6f\x6e\x28\x29\x7b\x7d\x5b\x27\x63\x6f\x6e\x73\x74\x72\x75\x63\x74\x6f\x72\x27\x5d\x28\x27\x64\x65\x62\x75\x67\x67\x65\x72\x27\x29\x28\x29\x29\x7d\x65\x6c\x73\x65\x7b\x28\x66\x75\x6e\x63\x74\x69\x6f\x6e\x28\x29\x7b\x7d\x5b\x27\x63\x6f\x6e\x73\x74\x72\x75\x63\x74\x6f\x72\x27\x5d\x28\x27\x64\x65\x62\x75\x67\x67\x65\x72\x27\x29\x28\x29\x29\x7d\x5f\x30\x78\x34\x37\x63\x37\x39\x65\x28\x2b\x2b\x5f\x30\x78\x35\x39\x65\x62\x31\x39\x29\x7d\x74\x72\x79\x7b\x5f\x30\x78\x34\x37\x63\x37\x39\x65\x28\x30\x78\x30\x29\x7d\x63\x61\x74\x63\x68\x28\x5f\x30\x78\x32\x62\x66\x38\x38\x61\x29\x7b\x7d\x7d\x3b\x5f\x30\x78\x31\x63\x38\x66\x36\x63\x28\x29\x3b");
function player(){
    $.post("api.php", {"referer":"<?php echo $_SERVER['HTTP_REFERER']?>", "time":"<?php echo TIMES;?>", "key": "<?php echo md5(TIMES.$key);?>", "url": "<?php echo $_GET['url'];?>","type": "<?php echo $get['type'];?>"},
    function(data){
        if(data['success'] == 1){
            var isiPad = navigator.userAgent.match(/iPad|iPhone|Linux|Android|iPod/i) != null;
            if(data['play'] == 'url'){
                 $('#a1').html('<iframe width="100%" height="100%" allowTransparency="true" frameborder="0" scrolling="no" src="'+data['url']+'"></iframe>');
            } else if(data['play'] == 'ajax'){
                if(data.type == 'youku'){
                    var get = getQuery(data.url);
                    data.ccode = get.ccode;
                    data.site  = data.type;
                    data.stype = get.stype;
                    data.vid   = get.vid;
                    data.weparser_js_url  = BASE64.de(decodeURIComponent(get.js_url));
                    data.weparser_swf_url = BASE64.de(decodeURIComponent(get.swf_url));
                    if(isiPad){
                        weParserParams = data;
                        var weParserJS = document.createElement("script");
                        weParserJS.type = "text/javascript";
                        weParserJS.src = data.weparser_js_url;
                        document.getElementsByTagName("head")[0].appendChild(weParserJS);
                    } else {
                        data.ext = 'xml';
                        data.url = '<?php echo YOU_URL?>xml.php?a=setswf&data='+BASE64.en($.param(data));
                        ckplayer_(data);
                    }
                } else if(data.type == 'qq'){
                    var get = getQuery(data.url);
                    $.ajax({
                        url: "//h5vv.video.qq.com/getinfo?charge=0&vid=" + get.vid + "&defaultfmt=auto&otype=json&guid=" + get.guid + "&platform=" + get.platform + "&defnpayver=1&appVer=3.0.83&sdtfrom=" + get.sdtfrom + "&host=v.qq.com&ehost=https%3A%2F%2Fv.qq.com%2Fx%2Fcover%2Fnuijxf6k13t6z9b%2Fl0023olk3g4.html&_0=" + get._0 + "&defn=mp4&fhdswitch=0&show1080p=1&isHLS=0&newplatform=" + get.sdtfrom + "&defsrc=1&_1=" + get._1 + "&_2=" + get._2,
                        dataType: 'jsonp',
                        jsonpCallback: "txplayerJsonpCallBack_getkey_" + parseInt(Math.random() * 800000 + 80000),
                        success: function(getinfo) {
                            if (!getinfo.exem) {
                                $.ajax({
                                    url: data.url + '&filename=' + getinfo.vl.vi[0].lnk + '.mp4',
                                    dataType: 'jsonp',
                                    jsonpCallback: "txplayerJsonpCallBack_getkey_" + parseInt(Math.random() * 800000 + 80000),
                                    success: function(json) {
                                        var get = getQuery(data.url);
                                        if (isiPad) {
                                            data.ext = 'h5';
                                            data.url = getinfo.vl.vi[0].ul.ui[0].url + json.filename + '?sdtfrom=' + get.sdtfrom + '&guid=' + get.guid + '&vkey=' + json.key
                                        } else {
                                            data.ext = 'xml';
                                            data.url = '<?php echo YOU_URL?>xml.php?a=setxml&url=' + BASE64.en(getinfo.vl.vi[0].ul.ui[0].url + json.filename + '?sdtfrom=' + get.sdtfrom + '&guid=' + get.guid + '&vkey=' + json.key)
                                        }
                                        ckplayer_(data)
                                    }
                                })
                            } else {
                                $('#loading').hide();
                                $('#a1').hide();
                                $('#error').html('<br><br><br><br><br>解析失败或资源不存在。');
                                $('#error').show();
                                return;
                            }
                        }
                    })
                } else if(data.type == 'iqiyi'){
                    $.ajax({
                        url: data.url.replace('http:', ''),
                        dataType: 'html',
                        success: function(json) {
                            json = eval("("+json.substring(17,json.length - 15)+")");
                            if (json.code == 'A00000') {
                                if (isiPad) {
                                    data.url = json.data.m3u;
                                    data.ext = 'h5';
                                    ckplayer_(data)
                                } else {
                                    var array = {};
                                    for (var i = json.data.vidl.length - 1; i >= 0; i--) {
                                        if (json.data.vidl[i].fileFormat != "H265") {
                                            array[json.data.vidl[i].vd] = json.data.vidl[i]
                                        }
                                    };
                                    if (array[4] != undefined) {
                                        data.url = array[4].m3u
                                    } else if (array[3] != undefined) {
                                        data.url = array[3].m3u
                                    } else if (array[2] != undefined) {
                                        data.url = array[2].m3u
                                    } else if (array[1] != undefined) {
                                        data.url = array[1].m3u
                                    } else if (array[96] != undefined) {
                                        data.url = array[96].m3u
                                    }
                                    data.url = 'xml.php?a=m3u8'+BASE64.en($.param(data));
                                    data.play = 'hls';
                                    var dplayer = new DPlayer({
                                        element: document.getElementById("a1"),
                                        autoplay: true,
                                        video: {
                                            url: data['url'],
                                            type: (data.play == 'h5mp4')? 'normal':data.play,
                                        }
                                    });
                                }
                            } else {
                                $('#loading').hide();
                                $('#a1').hide();
                                $('#error').html('<br><br><br><br><br>解析失败或资源不存在。');
                                $('#error').show();
                                return;
                            }
                        }
                    })
                }
            } else if(isiPad || data['play'] == 'html5'){
                 $('#a1').html('<video src="'+data['url']+'" controls="controls" autoplay="autoplay" width="100%" height="100%"></video>');
            } else if(data['play'] == 'h5mp4' || data['play'] == 'hls'){
                var dplayer = new DPlayer({
                    element: document.getElementById("a1"),
                    autoplay: true,
                    video: {
                        url: data['url'],
                        type: (data.play == 'h5mp4')? 'normal':data.play,
                    }
                });
            } else {
                ckplayer_(data);
            }
            $('#loading').hide();
            $('#a1').show();
        }else{
            $('#loading').hide();
            $('#a1').hide();
            if(data.msg == undefined){
                $('#error').html('<br><br><br><br><br>'+data['m']);
            } else {
                $('#error').html('<br><br><br><br><br>'+data['msg']);
            }
            $('#error').show();
        }
    },"json");
}
player();


(function(){

    var BASE64_MAPPING = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";

    var __BASE64 = {
        // 解密
        de:function (r) {
            var o = String(r).replace(/=+$/, "");
            if (o.length % 4 == 1)throw new t("'atob' failed: The string to be decoded is not correctly encoded.");
            for (var n, a, i = 0, c = 0, d = ""; a = o.charAt(c++); ~a && (n = i % 4 ? 64 * n + a : a, i++ % 4) ? d += String.fromCharCode(255 & n >> (-2 * i & 6)) : 0)a = BASE64_MAPPING.indexOf(a);
            return d
        },
        // 加密
        en:function (r) {
            for (var o, n, a = String(r), i = 0, c = BASE64_MAPPING, d = ""; a.charAt(0 | i) || (c = "=", i % 1); d += c.charAt(63 & o >> 8 - i % 1 * 8)) {
                if (n = a.charCodeAt(i += .75), n > 255)throw new t("'btoa' failed: The string to be encoded contains characters outside of the Latin1 range.");
                o = o << 8 | n
            }
            return d
        }
    };
    window.BASE64 = __BASE64;
})();
function getQuery(url) {
    if (typeof url !== 'string') {
        return null
    }
    var query = url.match(/[^\?]+\?([^#]*)/, '$1');
    if (!query || !query[1]) {
        return null
    }
    var kv = query[1].split('&');
    var map = {};
    for (var i = 0, len = kv.length; i < len; i++) {
        var result = kv[i].split('=');
        var key = result[0],
            value = result[1];
        map[key] = value || (typeof value == 'string' ? null : true)
    }
    return map
}

function ckplayer_(data){
    if(data.ext == 'h5'){
        $('#a1').html('<video src="'+data.url+'" controls="controls" autoplay="autoplay" width="100%" height="100%"></video>');
    } else {
        if(data['play'] == 'm3u8'){
             var flashvars={f:'<?php echo YOU_URL;?>ckplayer/m3u8.swf',a:data['url'],c:0,p:1,s:4,lv:0};
        } else {
             var flashvars={f:data['url'],c:0,s:2,p:1,b:1};
        }
        var params={bgcolor:'#FFF',allowFullScreen:true,allowScriptAccess:'always',wmode:'transparent'};
        CKobject.embedSWF('<?php echo YOU_URL;?>ckplayer/ckplayer.swf','a1','ckplayer_a1','100%','100%',flashvars,params);
    }
}
</script>
<!-- 想要添加统计代码或者接口广告的，可以放在这里 -->
</body>
</html>