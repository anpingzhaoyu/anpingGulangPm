<?php
//-----------------------请修改以下配置不懂的请看使用说明-----------------------------

//防盗链域名，多个用|隔开，如：123.com|abc.com（不会设置防盗链请留空）请看使用说明http://blog.odflv.com/?p=71
define('REFERER_URL', '');//请看使用说明http://blog.odflv.com/?p=71

//用户授权UID，在 http://www.odflv.com/user.jsp 平台可以查看到
define('USER_ID', '8000xxxx');

//用户授权Token，在 http://www.odflv.com/user.jsp 平台可以查看到
define('USER_TOKEN', 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');

//视频默认清晰度
define('VOD_HD', '2');

//配置百度的cookies信息，不会获取的请加交流群 488031388 在群文件里面看获取教程
define('BDUSS','');

//配置百度的SToken，不会获取的请加交流群 488031388 在群文件里面看获取教程
define('STOKEN','');

//-----------------------！！！修改区域结束以下内容禁止修改，否则会解析出错！！！----------------------------

//当前插件目录，无需修改
define('YOU_URL', web_path());
function web_path(){
    $uri = 'http://odflv'.$_SERVER['REQUEST_URI'];
    $arr = parse_url($uri);
    return str_replace(SELF,'',$arr['path']);
}
//错误提示
error_reporting(0);
//默认时区
date_default_timezone_set("Asia/Shanghai");
//强制编码
header('Content-type:text/html;charset=utf-8');
//当前时间，不能修改
define('TIMES', time());
require_once FCPATH.'url.php';
//生成加密KEY
$key = md5(USER_ID.YOU_URL.REFERER_URL);
//判断手机客户端
$wap = preg_match("/(iPhone|iPad|iPod|Linux|Android)/i", strtoupper($_SERVER['HTTP_USER_AGENT']));
//判断防盗链域名
function is_referer(){
    //没有设置防盗链
    if(REFERER_URL=='') return true; 
    //获取来路域名
    $uriarr = parse_url($_SERVER['HTTP_REFERER']);
    $host = $uriarr['host'];
    $ymarr = explode("|",REFERER_URL);
    if(in_array($host,$ymarr)){
        return true;
    }
    return false;
}
//获取远程内容
function geturl($url) {
    $headers1 = array(
        'referer' => $_POST['referer'],
        'Client-IP' => (empty($_SERVER['HTTP_CLIENT_IP'])? $_SERVER['REMOTE_ADDR'] : $_SERVER['HTTP_CLIENT_IP']),
        'X-Forwarded-For' => (empty($_SERVER['HTTP_X_FORWARDED_FOR'])? $_SERVER['REMOTE_ADDR'] : $_SERVER['HTTP_X_FORWARDED_FOR']), 
    );
    $url = $url.'&lref='.rawurlencode($_SERVER['HTTP_REFERER'])."&headers1=".rawurlencode(merge_string($headers1))."&ver=100&User-Agent=".base64_encode(base64_encode($_SERVER['HTTP_USER_AGENT']));
    // 判断是否支持CURL
    if (!function_exists('curl_init') || !function_exists('curl_exec')) {
        exit('您的主机不支持Curl，请开启~');
    }
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_USERAGENT, 'Cloud Parse');
    curl_setopt($curl, CURLOPT_REFERER, "http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
    curl_setopt($curl, CURLOPT_AUTOREFERER, 1);
    curl_setopt($curl, CURLOPT_TIMEOUT, 10);
    curl_setopt($curl, CURLOPT_HEADER, 0);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false); 
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false); 
    $data = curl_exec($curl);
    curl_close($curl);
    return $data;
}
//数组转XML
function xml($str,$param){
    global $hd;
    $param = str_replace('&','&amp;',$param);
    $xml='<ckplayer><!-- ODFLV视频解析群 642125668--><flashvars>{lv->0}{v->80}{e->0}{p->1}{q->start}{h->3}{f->'.YOU_URL.'api.php?'.$param.'&amp;[$pat]}{a->hd='.$hd.'}{defa->hd=1|hd=2|hd=3|hd=4}{deft->标清|高清|超清|原画}</flashvars>
    <video>';
    $arr = $str['url'];
    if(is_array($arr)){
             for($i=0;$i<count($arr);$i++){
                 $xml.='<file><![CDATA['.$arr[$i]['purl'].']]></file>';
                 if(isset($arr[$i]['size'])) $xml.='<size>'.$arr[$i]['size'].'</size>';
                 if(isset($arr[$i]['sec'])) $xml.='<seconds>'.$arr[$i]['sec'].'</seconds>';     
             }
    }else{
             $xml.='<file><![CDATA['.$str['url'].']]></file>';
             if(isset($str['size'])) $xml.='<size>'.$str['size'].'</size>';
             if(isset($str['sec'])) $xml.='<seconds>'.$str['sec'].'</seconds>';  
    }
    $xml.='</video></ckplayer>';
    return $xml;
}
function merge_string($a) {
    if (!is_array($a) && !is_object($a)) {
        return (string) $a;
    }
    return http_build_query(to_array($a));
}

function to_array($a) {
    $a = (array) $a;
    foreach ($a as &$v) {
        if (is_array($v) || is_object($v)) {
            $v = to_array($v);
        }
    }
    return $a;
}